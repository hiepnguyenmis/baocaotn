<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PayPalCheckoutController extends Controller
{
    public function GetCheckoutPaypal()
    {
        return view('page.index.CheckoutPayPal');
    }
}
